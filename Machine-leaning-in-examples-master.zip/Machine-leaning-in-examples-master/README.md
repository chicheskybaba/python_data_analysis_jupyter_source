# Machine-leaning-in_examples
Contains notebooks which can explain machine learning problem on examples
